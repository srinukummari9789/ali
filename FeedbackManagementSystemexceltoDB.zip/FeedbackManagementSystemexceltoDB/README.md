# Feedback Management System ExcelToDB application

This application is used to read the shared path excel file data and Writes to MySQL Data Base

# REST API

The REST APIs to the Feedback Management System ExcelToDB app is described below.

## Read ExcelData Write to DB

### Request

`GET /readExcel/`

	 http://localhost:8080/readExcel/

### Response 

data:{"headers":{},"body":{"id":0,"event_id":"DAE6601S","base_location":"hyderabad","beneficiary_name":"shaw","council_name":"ww","event_name":"hthht","event_description":"hh","event_date":"2014-02-09T18:30:00.000+0000","employee_id":"bvfb","employee_name":"A","volunteer_hours":10,"travel_hours":1,"lives_impacted":2,"business_unit":"grtg","event_status":"active","iiep_category":"fsff"},"statusCodeValue":200,"statusCode":"OK"}

data:{"headers":{},"body":{"id":0,"event_id":"JDHsdjhg","base_location":"ckdjcdkj","beneficiary_name":"vdvdv","council_name":"vdvv","event_name":"jjefefe","event_description":"efe","event_date":"2014-03-19T18:30:00.000+0000","employee_id":"kgjg","employee_name":"feufe","volunteer_hours":88,"travel_hours":0,"lives_impacted":5,"business_unit":"fef","event_status":"inactive","iiep_category":"hth"},"statusCodeValue":200,"statusCode":"OK"}

data:{"headers":{},"body":{"id":0,"event_id":"eeef","base_location":"cdsd","beneficiary_name":"vsfvbfb","council_name":"bdgbdgb","event_name":"bgdgb","event_description":"ngfn","event_date":"2015-05-02T18:30:00.000+0000","employee_id":"vfsdv","employee_name":"sfb","volunteer_hours":55,"travel_hours":2,"lives_impacted":2,"business_unit":"dbfbd","event_status":"dbd","iiep_category":"dfbd"},"statusCodeValue":200,"statusCode":"OK"}

data:{"headers":{},"body":{"id":0,"event_id":"ZZZZ","base_location":"hjhj","beneficiary_name":"gkgk","council_name":"hkgku","event_name":"drhd","event_description":"yfjf","event_date":"2020-02-09T18:30:00.000+0000","employee_id":"xfhgn","employee_name":"fbdf","volunteer_hours":11,"travel_hours":2,"lives_impacted":1,"business_unit":"jyj","event_status":"fjfj","iiep_category":"ddhd"},"statusCodeValue":200,"statusCode":"OK"}


## Get All Events

### Request

'GET' /getEvents/

	http://localhost:8080/getEvents/
	
### Response

[
    {
        "id": 1,
        "event_id": "DAE6601S",
        "base_location": "hyderabad",
        "beneficiary_name": "shaw",
        "council_name": "ww",
        "event_name": "hthht",
        "event_description": "hh",
        "event_date": "2014-02-09T18:30:00.000+0000",
        "employee_id": "bvfb",
        "employee_name": "A",
        "volunteer_hours": 10,
        "travel_hours": 1,
        "lives_impacted": 2,
        "business_unit": "grtg",
        "event_status": "active",
        "iiep_category": "fsff"
    },
    {
        "id": 2,
        "event_id": "JDHsdjhg",
        "base_location": "ckdjcdkj",
        "beneficiary_name": "vdvdv",
        "council_name": "vdvv",
        "event_name": "jjefefe",
        "event_description": "efe",
        "event_date": "2014-03-19T18:30:00.000+0000",
        "employee_id": "kgjg",
        "employee_name": "feufe",
        "volunteer_hours": 88,
        "travel_hours": 0,
        "lives_impacted": 5,
        "business_unit": "fef",
        "event_status": "inactive",
        "iiep_category": "hth"
    },
    {
        "id": 3,
        "event_id": "eeef",
        "base_location": "cdsd",
        "beneficiary_name": "vsfvbfb",
        "council_name": "bdgbdgb",
        "event_name": "bgdgb",
        "event_description": "ngfn",
        "event_date": "2015-05-02T18:30:00.000+0000",
        "employee_id": "vfsdv",
        "employee_name": "sfb",
        "volunteer_hours": 55,
        "travel_hours": 2,
        "lives_impacted": 2,
        "business_unit": "dbfbd",
        "event_status": "dbd",
        "iiep_category": "dfbd"
    },
    {
        "id": 4,
        "event_id": "ZZZZ",
        "base_location": "hjhj",
        "beneficiary_name": "gkgk",
        "council_name": "hkgku",
        "event_name": "drhd",
        "event_description": "yfjf",
        "event_date": "2020-02-09T18:30:00.000+0000",
        "employee_id": "xfhgn",
        "employee_name": "fbdf",
        "volunteer_hours": 11,
        "travel_hours": 2,
        "lives_impacted": 1,
        "business_unit": "jyj",
        "event_status": "fjfj",
        "iiep_category": "ddhd"
    },
    {
        "id": 5,
        "event_id": "DAE6601S",
        "base_location": "hyderabad",
        "beneficiary_name": "shaw",
        "council_name": "ww",
        "event_name": "hthht",
        "event_description": "hh",
        "event_date": "2014-02-09T18:30:00.000+0000",
        "employee_id": "bvfb",
        "employee_name": "A",
        "volunteer_hours": 10,
        "travel_hours": 1,
        "lives_impacted": 2,
        "business_unit": "grtg",
        "event_status": "active",
        "iiep_category": "fsff"
    },
    {
        "id": 6,
        "event_id": "JDHsdjhg",
        "base_location": "ckdjcdkj",
        "beneficiary_name": "vdvdv",
        "council_name": "vdvv",
        "event_name": "jjefefe",
        "event_description": "efe",
        "event_date": "2014-03-19T18:30:00.000+0000",
        "employee_id": "kgjg",
        "employee_name": "feufe",
        "volunteer_hours": 88,
        "travel_hours": 0,
        "lives_impacted": 5,
        "business_unit": "fef",
        "event_status": "inactive",
        "iiep_category": "hth"
    },
    {
        "id": 7,
        "event_id": "eeef",
        "base_location": "cdsd",
        "beneficiary_name": "vsfvbfb",
        "council_name": "bdgbdgb",
        "event_name": "bgdgb",
        "event_description": "ngfn",
        "event_date": "2015-05-02T18:30:00.000+0000",
        "employee_id": "vfsdv",
        "employee_name": "sfb",
        "volunteer_hours": 55,
        "travel_hours": 2,
        "lives_impacted": 2,
        "business_unit": "dbfbd",
        "event_status": "dbd",
        "iiep_category": "dfbd"
    },
    {
        "id": 8,
        "event_id": "ZZZZ",
        "base_location": "hjhj",
        "beneficiary_name": "gkgk",
        "council_name": "hkgku",
        "event_name": "drhd",
        "event_description": "yfjf",
        "event_date": "2020-02-09T18:30:00.000+0000",
        "employee_id": "xfhgn",
        "employee_name": "fbdf",
        "volunteer_hours": 11,
        "travel_hours": 2,
        "lives_impacted": 1,
        "business_unit": "jyj",
        "event_status": "fjfj",
        "iiep_category": "ddhd"
    }
]
