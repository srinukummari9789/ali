package com.capstone.feedbackmanagementsystem.exceltodb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capstone.feedbackmanagementsystem.exceltodb.Service.EventService;
import com.capstone.feedbackmanagementsystem.exceltodb.entity.Events;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import reactor.core.publisher.Flux;

@RestController
public class EventController {
	private static final Logger LOGGER = LogManager.getLogger(EventController.class);
	
	
	@Autowired
	private EventService eventService;
	
	  @GetMapping(value = "/readExcel", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	  public Flux<Object> uploadFile() throws Exception { 
		  LOGGER.info("readExcel:::::::::::::::::::::::::::::");
		  return eventService.saveExcelData();
	  }
		
	  @GetMapping(value = "/getEvents") 
	  public Flux<Events> getEvents(){
		  LOGGER.info("getEvents:::::::::::::::::::::::::::::");
		  return eventService.getAllEvents();
	  }
	 
	
}
