package com.capstone.feedbackmanagementsystem.exceltodb.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.capstone.feedbackmanagementsystem.exceltodb.entity.Events;

@Repository
public interface EventRepository extends ReactiveCrudRepository<Events, Long> {

}
